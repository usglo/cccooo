<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['config'] = array('debugbar');
$autoload['language'] = array('profiler');
$autoload['libraries'] = array('session','console');